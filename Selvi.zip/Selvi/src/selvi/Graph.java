package selvi;
import java.util.*;
public class Graph {
	ArrayList<ArrayList<Integer>> adj=new ArrayList<>();
	Graph(int v){
		for(int i=0;i<v;i++) {
			adj.add(new ArrayList<>());
		}
	}
	public void addEdge(int u,int v) {
		if(u>=0 && u<adj.size() && v>=0 && v<adj.size()) {
			adj.get(u).add(v);
			adj.get(v).add(u);
		}
	}
	public void printList() {
		for(int i=0;i<adj.size();i++) {
			System.out.print(i+" :");
			for(int j=0;j<adj.get(i).size();j++) {
				System.out.print(" "+adj.get(i).get(j));
			}
			System.out.println();
		}
		
	}
	public void BFS(int start) {
		int vertex=adj.size();
		boolean[] visited=new boolean[vertex];
		Queue<Integer> q=new LinkedList<>();
		q.add(start);
		visited[start]=true;
		System.out.println("The path is:");
		while(q.size()!=0) {
			int ver=q.remove();
			System.out.print(" "+ver);
			for(int i=0;i<adj.get(ver).size();i++) {
				int av=adj.get(ver).get(i);
				if(!visited[av]) {
					q.add(av);
					visited[av]=true;
				}
			}
		}
		System.out.println();
	}
	public void DFS(int vertex) {
		int ver=adj.size();
		boolean[] visited=new boolean[ver];
		dfs2(vertex,visited);
	}
	public void dfs2(int ver,boolean[] visited) {
		visited[ver]=true;
		//System.out.println("The path is:");
		System.out.print(" "+ver);
		for(int i=0;i<adj.get(ver).size();i++) {
			int av=adj.get(ver).get(i);
			if(!visited[av]) {
				dfs2(av,visited);
			}
		}
	}
}
