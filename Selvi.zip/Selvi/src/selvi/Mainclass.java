package selvi;
import java.util.*;
public class Mainclass {
	public static void main(String args[]) {
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter the number of vertices:");
		int v=scan.nextInt();
		Graph g=new Graph(v);
		System.out.println("Enter number of edges:");
		int edge=scan.nextInt();
		for(int i=0;i<edge;i++) {
			System.out.println("Enter the start node:");
			int start=scan.nextInt();
			System.out.println("Enter the end node:");
			int end=scan.nextInt();
			g.addEdge(start,end);
		}
		System.out.println("The graph is:");
		g.printList();
		System.out.println("Enter the start node:");
		int start=scan.nextInt();
		System.out.println("BFS");
		g.BFS(start);
		System.out.println("DFS");
		g.DFS(start);
		scan.close();
	}
}
